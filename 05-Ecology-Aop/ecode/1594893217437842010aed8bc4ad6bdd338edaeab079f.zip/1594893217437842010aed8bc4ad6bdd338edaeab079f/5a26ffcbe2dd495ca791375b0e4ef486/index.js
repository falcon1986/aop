const { Provider } = mobxReact;
const MainPage = ecodeSDK.imp(MainPage);
const allStore = ecodeSDK.imp(allStore);

class Root extends React.Component {
  render() {
    return (
      <Provider {...allStore}>
        <MainPage {...this.props} />
      </Provider>
    )
  }
}

//要配合init.js来注册到对应业务场景
//发布模块Page1，作为模块${appId}的子模块
ecodeSDK.setCom('${appId}', 'demoHrm', Root);











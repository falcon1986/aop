const MainStore = ecodeSDK.imp(MainStore)

const allStore = {
  mainStore: new MainStore()
}
ecodeSDK.exp(allStore);









const { observable, action, toJS } = mobx;
const { message, Modal } = antd;
const { WeaForm, WeaTableNew } = comsMobx;
const { WeaLocaleProvider } = ecCom;
const API = ecodeSDK.imp(API);

const { TableStore } = WeaTableNew;

class MainStore{
  @observable currentUrl = "/wui/index.html#/main/cs/app/5a26ffcbe2dd495ca791375b0e4ef486_demoHrm";
  @observable title = 'demo人员'; // 标题
  @observable loading = false; // 数据加载状态
  @observable loadingInfo = ""; // 数据加载信息
  @observable hasRight = true; //查看页面权限
  @observable rightLevel = 1; //1-普通员工  2-管理员
  @observable showSearchAd = false; //是否展开高级搜索
  @observable tableStore = new TableStore(); //分页列表数据
  @observable form = new WeaForm();
  @observable condition = []; // 存储后台得到的form数据
  @observable selectedRowKeys = []; //表格选中的数据

  @action
  getRightMenu = () => {
    var arr = [{
      key: 'BTN_SEARCH',
      icon: <i className='icon-coms-search'/>,
      content : WeaLocaleProvider.getLabel(197, '搜索'),
      onClick : this.doSearch
    },{
      key: 'BTN_RESEARCH',
      icon: <i className='icon-coms-go-back'/>,
      content : WeaLocaleProvider.getLabel(364, '重新搜索'),
      onClick : this.doReSearch
    }];

    arr.push(
      {
        key: 'BTN_EXPORT',
        icon: <i className='icon-coms-export'/>,
        content : WeaLocaleProvider.getLabel(28343, '导出Excel'),
        onClick : this.exportExcelAll
      }
    );

    arr.push(
      {
        key: 'BTN_COLUMN',
        icon: <i className='icon-coms-Custom'/>,
        content : WeaLocaleProvider.getLabel(32535, '显示列定制'),
        onClick : this.showColumn
      }
    );
    return arr;
  }

  @action 
  getTopBtn = () => {    
    return [];
  }

  @action
  doInit = () => {
    this.getCondition();
  }

  @action
  getCondition = () => {
    API.getCondition().then(action(res => {
        this.condition = res.condition;
        this.form.initFormFields(res.condition); // 渲染高级搜索form表单
        this.doSearch();
    }));
  }

  @action
  setShowSearchAd = bool => this.showSearchAd = bool;

  @action 
  doSearch = () => {
    this.getTableDatas();
    this.showSearchAd = false;
  }

  @action 
  doReSearch = () => {
    this.form.resetConditionValue();
    this.doSearch();
  }

  @action 
  exportExcelAll = () => {
    this.tableStore.exportAll();
  }

  @action
  getTableDatas = (toFirstPage = true) => {
    const formParams = this.form.getFormParams() || {};
    API.getTableDatas(formParams).then(action(res => {
        toFirstPage ? this.tableStore.getDatas(res.datas, 1) : this.tableStore.getDatas(res.datas); // table 请求数据
        this.hasRight = res.hasRight;
        if(res.rightLevel){
          this.rightLevel = res.rightLevel;
        }
    }));
  }

  @action
  onOperatesClick = (record, index, operate, flag) => {
    switch(operate.index.toString()){
      case '0': 
        break;
      default:
        break;
    }
  };


  @action
  getColumns = (columns) => {
    let newColumns = '';
    newColumns = columns.map(column => {
      let newColumn = column;
      newColumn.render = (text, record, index) => { //前端元素转义
        let valueSpan = record[newColumn.dataIndex + "span"] !== undefined ? record[newColumn.dataIndex + "span"] : record[newColumn.dataIndex];
        return (
          (this.rightLevel > 1 && (newColumn.dataIndex == 'CODE' || newColumn.dataIndex == 'NAME')) ?
            <a onClick={() => {this.saveStore.onEdit(record.randomFieldId)}}
               dangerouslySetInnerHTML={{ __html: valueSpan }} />
            :
            <div dangerouslySetInnerHTML={{ __html: valueSpan }} />
        )
      }
      return newColumn;
    });
    return newColumns;
  }

  @action
  showColumn = () => {
    this.tableStore.setColSetVisible(true);
    this.tableStore.tableColSet(true);
  }

  @action
  doDeleteBatch = () => {
    this.doDelete(this.tableStore.selectedRowKeys);
  }

  @action
  doDelete = ids =>{
    if(typeof(ids) == "undefined" || ids == ""){
       message.error(WeaLocaleProvider.getLabel(19689, '请先选择操作的记录！'));
       return;
    }

    Modal.confirm({
      title: WeaLocaleProvider.getLabel(15172, '系统提示'),
      content: WeaLocaleProvider.getLabel(33475, '确定删除选中记录吗？'),
      onOk: () => {
        this.startLoading();
        API.doDelete({id: ids}).then(action(res => {
          this.endLoading();
          if (res.api_status && res.api_service_status) {
            this.doSearch();
            message.success(WeaLocaleProvider.getLabel(30700, '操作成功'));
          } else {
            message.error(res.api_errormsg || WeaLocaleProvider.getLabel(30651, '操作失败'))
          }
        }));
      },
    });
  }

  @action
  doDisabledOrNot = (type, ids) =>{
    if(typeof(ids) == "undefined" || ids == ""){
       message.error(WeaLocaleProvider.getLabel(19689, '请先选择操作的记录！'));
       return;
    }

    Modal.confirm({
      title: WeaLocaleProvider.getLabel(15172, '系统提示'),
      content: WeaLocaleProvider.getLabel(24248, '你确定要提交吗？'),
      onOk: () => {
        this.startLoading();
        API.doDisabledOrNot({type: type, id: ids}).then(action(res => {
          this.endLoading();
          if (res.api_status && res.api_service_status) {
            this.doSearch();
            message.success(WeaLocaleProvider.getLabel(30700, '操作成功'));
          } else {
            message.error(res.api_errormsg || WeaLocaleProvider.getLabel(30651, '操作失败'))
          }
        }));
      },
    });
  }

  @action
  startLoading = (msg) => {
    if(msg){
      this.loadingInfo = msg;
    }
    if(!this.loadingInfo){
      this.loadingInfo = WeaLocaleProvider.getLabel(20204, '正在处理数据，请稍等....');
    }
    this.loading = true;
  } 

  @action
  endLoading = () => {
    this.loadingInfo = "";
    this.loading = false;
  } 
}

ecodeSDK.exp(MainStore);









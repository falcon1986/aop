"use strict";

var MainStore = ecodeSDK.imp(MainStore);
var allStore = {
  mainStore: new MainStore()
};
ecodeSDK.exp(allStore);









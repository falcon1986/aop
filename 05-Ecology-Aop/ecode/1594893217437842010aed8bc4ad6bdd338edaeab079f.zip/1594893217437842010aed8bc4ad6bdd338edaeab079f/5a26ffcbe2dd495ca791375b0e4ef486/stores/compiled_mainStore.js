"use strict";

var _class, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _descriptor17, _descriptor18, _descriptor19, _descriptor20, _descriptor21, _descriptor22, _descriptor23, _descriptor24, _descriptor25, _descriptor26, _descriptor27, _descriptor28, _temp;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and set to use loose mode. ' + 'To use proposal-class-properties in spec mode with decorators, wait for ' + 'the next major version of decorators in stage 2.'); }

var _mobx = mobx,
    observable = _mobx.observable,
    action = _mobx.action,
    toJS = _mobx.toJS;
var _antd = antd,
    message = _antd.message,
    Modal = _antd.Modal;
var _comsMobx = comsMobx,
    WeaForm = _comsMobx.WeaForm,
    WeaTableNew = _comsMobx.WeaTableNew;
var _ecCom = ecCom,
    WeaLocaleProvider = _ecCom.WeaLocaleProvider;
var API = ecodeSDK.imp(API);
var TableStore = WeaTableNew.TableStore;
var MainStore = (_class = (_temp = function MainStore() {
  _classCallCheck(this, MainStore);

  _initializerDefineProperty(this, "currentUrl", _descriptor, this);

  _initializerDefineProperty(this, "title", _descriptor2, this);

  _initializerDefineProperty(this, "loading", _descriptor3, this);

  _initializerDefineProperty(this, "loadingInfo", _descriptor4, this);

  _initializerDefineProperty(this, "hasRight", _descriptor5, this);

  _initializerDefineProperty(this, "rightLevel", _descriptor6, this);

  _initializerDefineProperty(this, "showSearchAd", _descriptor7, this);

  _initializerDefineProperty(this, "tableStore", _descriptor8, this);

  _initializerDefineProperty(this, "form", _descriptor9, this);

  _initializerDefineProperty(this, "condition", _descriptor10, this);

  _initializerDefineProperty(this, "selectedRowKeys", _descriptor11, this);

  _initializerDefineProperty(this, "getRightMenu", _descriptor12, this);

  _initializerDefineProperty(this, "getTopBtn", _descriptor13, this);

  _initializerDefineProperty(this, "doInit", _descriptor14, this);

  _initializerDefineProperty(this, "getCondition", _descriptor15, this);

  _initializerDefineProperty(this, "setShowSearchAd", _descriptor16, this);

  _initializerDefineProperty(this, "doSearch", _descriptor17, this);

  _initializerDefineProperty(this, "doReSearch", _descriptor18, this);

  _initializerDefineProperty(this, "exportExcelAll", _descriptor19, this);

  _initializerDefineProperty(this, "getTableDatas", _descriptor20, this);

  _initializerDefineProperty(this, "onOperatesClick", _descriptor21, this);

  _initializerDefineProperty(this, "getColumns", _descriptor22, this);

  _initializerDefineProperty(this, "showColumn", _descriptor23, this);

  _initializerDefineProperty(this, "doDeleteBatch", _descriptor24, this);

  _initializerDefineProperty(this, "doDelete", _descriptor25, this);

  _initializerDefineProperty(this, "doDisabledOrNot", _descriptor26, this);

  _initializerDefineProperty(this, "startLoading", _descriptor27, this);

  _initializerDefineProperty(this, "endLoading", _descriptor28, this);
}, _temp), (_descriptor = _applyDecoratedDescriptor(_class.prototype, "currentUrl", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return "/wui/index.html#/main/cs/app/5a26ffcbe2dd495ca791375b0e4ef486_demoHrm";
  }
}), _descriptor2 = _applyDecoratedDescriptor(_class.prototype, "title", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return 'demo人员';
  }
}), _descriptor3 = _applyDecoratedDescriptor(_class.prototype, "loading", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return false;
  }
}), _descriptor4 = _applyDecoratedDescriptor(_class.prototype, "loadingInfo", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return "";
  }
}), _descriptor5 = _applyDecoratedDescriptor(_class.prototype, "hasRight", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return true;
  }
}), _descriptor6 = _applyDecoratedDescriptor(_class.prototype, "rightLevel", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return 1;
  }
}), _descriptor7 = _applyDecoratedDescriptor(_class.prototype, "showSearchAd", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return false;
  }
}), _descriptor8 = _applyDecoratedDescriptor(_class.prototype, "tableStore", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return new TableStore();
  }
}), _descriptor9 = _applyDecoratedDescriptor(_class.prototype, "form", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return new WeaForm();
  }
}), _descriptor10 = _applyDecoratedDescriptor(_class.prototype, "condition", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor11 = _applyDecoratedDescriptor(_class.prototype, "selectedRowKeys", [observable], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return [];
  }
}), _descriptor12 = _applyDecoratedDescriptor(_class.prototype, "getRightMenu", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this = this;

    return function () {
      var arr = [{
        key: 'BTN_SEARCH',
        icon: React.createElement("i", {
          className: "icon-coms-search"
        }),
        content: WeaLocaleProvider.getLabel(197, '搜索'),
        onClick: _this.doSearch
      }, {
        key: 'BTN_RESEARCH',
        icon: React.createElement("i", {
          className: "icon-coms-go-back"
        }),
        content: WeaLocaleProvider.getLabel(364, '重新搜索'),
        onClick: _this.doReSearch
      }];
      arr.push({
        key: 'BTN_EXPORT',
        icon: React.createElement("i", {
          className: "icon-coms-export"
        }),
        content: WeaLocaleProvider.getLabel(28343, '导出Excel'),
        onClick: _this.exportExcelAll
      });
      arr.push({
        key: 'BTN_COLUMN',
        icon: React.createElement("i", {
          className: "icon-coms-Custom"
        }),
        content: WeaLocaleProvider.getLabel(32535, '显示列定制'),
        onClick: _this.showColumn
      });
      return arr;
    };
  }
}), _descriptor13 = _applyDecoratedDescriptor(_class.prototype, "getTopBtn", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return function () {
      return [];
    };
  }
}), _descriptor14 = _applyDecoratedDescriptor(_class.prototype, "doInit", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this2 = this;

    return function () {
      _this2.getCondition();
    };
  }
}), _descriptor15 = _applyDecoratedDescriptor(_class.prototype, "getCondition", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this3 = this;

    return function () {
      API.getCondition().then(action(function (res) {
        _this3.condition = res.condition;

        _this3.form.initFormFields(res.condition); // 渲染高级搜索form表单


        _this3.doSearch();
      }));
    };
  }
}), _descriptor16 = _applyDecoratedDescriptor(_class.prototype, "setShowSearchAd", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this4 = this;

    return function (bool) {
      return _this4.showSearchAd = bool;
    };
  }
}), _descriptor17 = _applyDecoratedDescriptor(_class.prototype, "doSearch", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this5 = this;

    return function () {
      _this5.getTableDatas();

      _this5.showSearchAd = false;
    };
  }
}), _descriptor18 = _applyDecoratedDescriptor(_class.prototype, "doReSearch", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this6 = this;

    return function () {
      _this6.form.resetConditionValue();

      _this6.doSearch();
    };
  }
}), _descriptor19 = _applyDecoratedDescriptor(_class.prototype, "exportExcelAll", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this7 = this;

    return function () {
      _this7.tableStore.exportAll();
    };
  }
}), _descriptor20 = _applyDecoratedDescriptor(_class.prototype, "getTableDatas", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this8 = this;

    return function () {
      var toFirstPage = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
      var formParams = _this8.form.getFormParams() || {};
      API.getTableDatas(formParams).then(action(function (res) {
        toFirstPage ? _this8.tableStore.getDatas(res.datas, 1) : _this8.tableStore.getDatas(res.datas); // table 请求数据

        _this8.hasRight = res.hasRight;

        if (res.rightLevel) {
          _this8.rightLevel = res.rightLevel;
        }
      }));
    };
  }
}), _descriptor21 = _applyDecoratedDescriptor(_class.prototype, "onOperatesClick", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    return function (record, index, operate, flag) {
      switch (operate.index.toString()) {
        case '0':
          break;

        default:
          break;
      }
    };
  }
}), _descriptor22 = _applyDecoratedDescriptor(_class.prototype, "getColumns", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this9 = this;

    return function (columns) {
      var newColumns = '';
      newColumns = columns.map(function (column) {
        var newColumn = column;

        newColumn.render = function (text, record, index) {
          //前端元素转义
          var valueSpan = record[newColumn.dataIndex + "span"] !== undefined ? record[newColumn.dataIndex + "span"] : record[newColumn.dataIndex];
          return _this9.rightLevel > 1 && (newColumn.dataIndex == 'CODE' || newColumn.dataIndex == 'NAME') ? React.createElement("a", {
            onClick: function onClick() {
              _this9.saveStore.onEdit(record.randomFieldId);
            },
            dangerouslySetInnerHTML: {
              __html: valueSpan
            }
          }) : React.createElement("div", {
            dangerouslySetInnerHTML: {
              __html: valueSpan
            }
          });
        };

        return newColumn;
      });
      return newColumns;
    };
  }
}), _descriptor23 = _applyDecoratedDescriptor(_class.prototype, "showColumn", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this10 = this;

    return function () {
      _this10.tableStore.setColSetVisible(true);

      _this10.tableStore.tableColSet(true);
    };
  }
}), _descriptor24 = _applyDecoratedDescriptor(_class.prototype, "doDeleteBatch", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this11 = this;

    return function () {
      _this11.doDelete(_this11.tableStore.selectedRowKeys);
    };
  }
}), _descriptor25 = _applyDecoratedDescriptor(_class.prototype, "doDelete", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this12 = this;

    return function (ids) {
      if (typeof ids == "undefined" || ids == "") {
        message.error(WeaLocaleProvider.getLabel(19689, '请先选择操作的记录！'));
        return;
      }

      Modal.confirm({
        title: WeaLocaleProvider.getLabel(15172, '系统提示'),
        content: WeaLocaleProvider.getLabel(33475, '确定删除选中记录吗？'),
        onOk: function onOk() {
          _this12.startLoading();

          API.doDelete({
            id: ids
          }).then(action(function (res) {
            _this12.endLoading();

            if (res.api_status && res.api_service_status) {
              _this12.doSearch();

              message.success(WeaLocaleProvider.getLabel(30700, '操作成功'));
            } else {
              message.error(res.api_errormsg || WeaLocaleProvider.getLabel(30651, '操作失败'));
            }
          }));
        }
      });
    };
  }
}), _descriptor26 = _applyDecoratedDescriptor(_class.prototype, "doDisabledOrNot", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this13 = this;

    return function (type, ids) {
      if (typeof ids == "undefined" || ids == "") {
        message.error(WeaLocaleProvider.getLabel(19689, '请先选择操作的记录！'));
        return;
      }

      Modal.confirm({
        title: WeaLocaleProvider.getLabel(15172, '系统提示'),
        content: WeaLocaleProvider.getLabel(24248, '你确定要提交吗？'),
        onOk: function onOk() {
          _this13.startLoading();

          API.doDisabledOrNot({
            type: type,
            id: ids
          }).then(action(function (res) {
            _this13.endLoading();

            if (res.api_status && res.api_service_status) {
              _this13.doSearch();

              message.success(WeaLocaleProvider.getLabel(30700, '操作成功'));
            } else {
              message.error(res.api_errormsg || WeaLocaleProvider.getLabel(30651, '操作失败'));
            }
          }));
        }
      });
    };
  }
}), _descriptor27 = _applyDecoratedDescriptor(_class.prototype, "startLoading", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this14 = this;

    return function (msg) {
      if (msg) {
        _this14.loadingInfo = msg;
      }

      if (!_this14.loadingInfo) {
        _this14.loadingInfo = WeaLocaleProvider.getLabel(20204, '正在处理数据，请稍等....');
      }

      _this14.loading = true;
    };
  }
}), _descriptor28 = _applyDecoratedDescriptor(_class.prototype, "endLoading", [action], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: function initializer() {
    var _this15 = this;

    return function () {
      _this15.loadingInfo = "";
      _this15.loading = false;
    };
  }
})), _class);
ecodeSDK.exp(MainStore);

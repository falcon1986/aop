"use strict";

var _antd = antd,
    Spin = _antd.Spin;
var _comsMobx = comsMobx,
    WeaSwitch = _comsMobx.WeaSwitch;
var _ecCom = ecCom,
    WeaLocaleProvider = _ecCom.WeaLocaleProvider,
    WeaAlertPage = _ecCom.WeaAlertPage,
    WeaSearchGroup = _ecCom.WeaSearchGroup,
    WeaFormItem = _ecCom.WeaFormItem;
var getLabel = WeaLocaleProvider.getLabel; // 渲染form表单: 一般对form的渲染都统一使用该方法

var getSearchs = function getSearchs(form, condition, col, isCenter) {
  var isFormInit = form.isFormInit;
  var formParams = form.getFormParams();
  var group = [];
  isFormInit && condition && condition.map(function (c) {
    var items = [];
    c.items.map(function (fields) {
      items.push({
        com: React.createElement(WeaFormItem, {
          label: "".concat(fields.label) // label 标签的文本
          ,
          labelCol: {
            span: "".concat(fields.labelcol)
          } // label标签占一行比例
          ,
          wrapperCol: {
            span: "".concat(fields.fieldcol)
          } // 右侧控件占一行比例
          ,
          error: form.getError(fields) // 错误提示: 处理表单中有必填项,保存的校验
          ,
          tipPosition: "bottom" // 错误提示的显示位置: top/bottom

        }, React.createElement(WeaSwitch, {
          fieldConfig: fields,
          form: form,
          formParams: formParams
        })),
        colSpan: 1
      });
    });
    group.push(React.createElement(WeaSearchGroup, {
      col: col || 1 // 高级搜索列布局列数
      ,
      needTigger: true // 是否开启收缩
      ,
      title: c.title || '' // 高级搜索标题
      ,
      showGroup: c.defaultshow // 是否开启面板
      ,
      items: items // 条目数组数据
      ,
      center: isCenter || false // 内容是否居中：一般弹框需要

    }));
  });
  return group;
}; // 页面加载中效果处理


var renderLoading = function renderLoading(loading) {
  return React.createElement("div", {
    className: "wea-demo-loading"
  }, React.createElement(Spin, {
    spinning: loading
  }));
}; // 无权限处理


var renderNoright = function renderNoright() {
  return React.createElement(WeaAlertPage, null, React.createElement("div", null, getLabel(2012, '对不起，您暂时没有权限！')));
}; // 暂无数据处理


var renderNoData = function renderNoData() {
  return React.createElement(WeaAlertPage, null, React.createElement("div", null, getLabel(83553, '暂无数据')));
}; // 收藏功能: 配置之后显示 收藏、帮助、显示页面地址 这3个功能


var getCollectParams = function getCollectParams(url, name) {
  var collectParams = {
    // 收藏功能配置
    favname: name,
    favouritetype: 1,
    objid: 0,
    link: url
  };
  return collectParams;
}; //渲染数据到表单


var parseRecordToForm = function parseRecordToForm(form, res) {
  if (form && form.getFormDatas()) {
    for (var key in form.getFormDatas()) {
      if (!res[key]) {
        continue;
      }

      if ("browser" == res[key].type) {
        (function () {
          var valueObj = [];
          var valueArr = res[key].value.split(",");
          var valueSpanArr = res[key].valueSpan.split(",");
          valueArr.map(function (info, index) {
            var valueSpan = valueSpanArr[index];

            if (info && valueSpan) {
              valueObj.push({
                id: info,
                name: valueSpan
              });
            }
          });
          var v = {};
          v[key] = {
            value: res[key].value,
            valueSpan: res[key].valueSpan,
            valueObj: valueObj
          };
          form.updateFields(v);
        })();
      } else {
        var v = {};
        v[key] = {
          value: res[key].value
        };
        form.updateFields(v);
      }
    }
  }
};

var util = {
  getSearchs: getSearchs,
  renderLoading: renderLoading,
  renderNoright: renderNoright,
  renderNoData: renderNoData,
  getCollectParams: getCollectParams,
  parseRecordToForm: parseRecordToForm
};
ecodeSDK.exp(util);









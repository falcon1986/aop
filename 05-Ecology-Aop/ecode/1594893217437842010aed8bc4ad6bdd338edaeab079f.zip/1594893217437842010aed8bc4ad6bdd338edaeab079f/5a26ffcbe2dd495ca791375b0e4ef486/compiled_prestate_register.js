"use strict";

//注册和绑定新页面前端实现接口
ecodeSDK.rewriteRouteQueue.push({
  fn: function fn(params) {
    var Com = params.Com,
        Route = params.Route,
        nextState = params.nextState;
    var cpParams = {
      path: 'main/cs/app',
      //路由地址
      appId: '${appId}',
      name: 'demoHrm',
      //具体页面应用id
      node: 'app',
      //渲染的路由节点，这里渲染的是app这个节点
      Route: Route,
      nextState: nextState
    };

    if (ecodeSDK.checkPath(cpParams)) {
      var acParams = {
        appId: cpParams.appId,
        name: cpParams.name,
        //模块名称
        props: params,
        //参数
        isPage: true,
        //是否是路由页面
        noCss: false //是否禁止单独加载css，通常为了减少css数量，css默认前置加载
        //异步加载模块${appId}下的子模块Page1

      };
      return ecodeSDK.getAsyncCom(acParams);
    }

    return null;
  },
  order: 2,
  desc: 'demo人员'
});
/*
版本要求：kb1906以上
配置路由地址：
/main/cs/app/5a26ffcbe2dd495ca791375b0e4ef486_demoHrm
浏览器访问地址：
/wui/index.html#/main/cs/app/5a26ffcbe2dd495ca791375b0e4ef486_demoHrm
*/

const { observable, action, toJS } = mobx;
const { inject, observer } = mobxReact;
const { WeaTableNew } = comsMobx;
const WeaTable = WeaTableNew.WeaTable;
const { Button, Spin } = antd;
const { WeaTop, WeaTab, WeaRightMenu, WeaLeftRightLayout, WeaLeftTree, WeaDialog, WeaLocaleProvider, WeaSearchGroup, WeaInput, WeaFormItem, WeaUpload } = ecCom;
const { renderNoright, getSearchs, getCollectParams } = ecodeSDK.imp(util);

@inject('mainStore')
@observer
class MainPage extends React.Component{
  //初始化
  componentWillMount() {
    const { mainStore } = this.props;
    mainStore.doInit();
  }

  // 高级搜索内部按钮
  getSearchAdBtn = () => {
    const { mainStore:{doSearch, form, setShowSearchAd} } = this.props;
    const btn = [ 
      <Button type="primary" onClick={doSearch}>{WeaLocaleProvider.getLabel(197, '搜索')}</Button>,
      <Button type="ghost" onClick={() => form.resetForm()}>{WeaLocaleProvider.getLabel(2022, '重置')}</Button>,
      <Button type="ghost" onClick={() => setShowSearchAd(false)}>{WeaLocaleProvider.getLabel(201, '取消')}</Button>,
    ];
    return btn;
  }

  render(){
    const { mainStore } = this.props;
    const { title, showSearchAd, condition, form, tableStore, currentUrl, loading, loadingInfo, selectedRowKeys, hasRight, hideLeft } = mainStore;
    const { getColumns, onOperatesClick } = mainStore;
    const { getTableDatas, setShowSearchAd, doSearch, getRightMenu, getTopBtn } = mainStore;
    const { rightLevel } = mainStore;

    const rightMenu = getRightMenu();
    const collectParams = getCollectParams(currentUrl);
    const searchAdBtn = this.getSearchAdBtn();
    const topBtn = getTopBtn();

    return (
      <div>
        <Spin size="large" spinning={loading} tip={loadingInfo}>
          <WeaRightMenu
            datas={rightMenu} // 右键菜单
            collectParams={collectParams} // 收藏功能: 配置之后显示 收藏、帮助、显示页面地址 这3个功能
          >
            <WeaTop
                title={title} // 文字
                icon={<img style={{width:35,height:35,marginTop:8}} src ='/westvalley/tool/am/image/ico_asset.png' />} // 左侧图标
                showDropIcon={true} // 是否显示下拉按钮
                dropMenuDatas={rightMenu} // 下拉菜单（和页面的右键菜单相同）
                dropMenuProps={{ collectParams }} // 收藏功能: 配置之后显示 收藏、帮助、显示页面地址 这3个功能
                buttons={topBtn} // 顶部按钮
                buttonSpace={10} // 按钮之间的间隔
                loading={loading} // 头部加载进度条
              >
              <WeaTab
                searchType={['base', 'advanced']} // base：基础搜索框 advanced：显示高级搜索按钮
                showSearchAd={showSearchAd} // 是否展开高级搜索面板
                setShowSearchAd={bool => setShowSearchAd(bool)} //高级搜索面板受控
                searchsAd={getSearchs(form, toJS(condition), 2)} // 高级搜索内部数据
                buttonsAd={searchAdBtn} // 高级搜索内部按钮
                onSearch={getTableDatas} // 点搜索按钮时的回调
                onSearchChange={v => form.updateFields({ name: v })} // 在搜索框中输入的文字改变时的回调: 这里需要同步高级搜索和外部搜索框的值
                searchsBaseValue={form.getFormParams().name} // 外部input搜索值受控: 这里和高级搜索的requestname同步
              />
              <WeaTable // table内部做了loading加载处理，页面就不需要再加了
                comsWeaTableStore={tableStore} // table store
                hasOrder={true} // 是否启用排序
                needScroll={true} // 是否启用table内部列表滚动，将自适应到父级高度
                getColumns={getColumns} // 重定列各列属性(一般带编辑功能，点击第一列字段的时候需要同样打开编辑弹框)
                onOperatesClick={onOperatesClick.bind(this)} // 自定义操作按钮点击方法
              />
            </WeaTop>
          </WeaRightMenu>
        </Spin>
      </div>           
    );
  }
}

ecodeSDK.exp(MainPage);









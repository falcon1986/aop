"use strict";

var _dec, _class, _temp;

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _mobx = mobx,
    observable = _mobx.observable,
    action = _mobx.action,
    toJS = _mobx.toJS;
var _mobxReact = mobxReact,
    inject = _mobxReact.inject,
    observer = _mobxReact.observer;
var _comsMobx = comsMobx,
    WeaTableNew = _comsMobx.WeaTableNew;
var WeaTable = WeaTableNew.WeaTable;
var _antd = antd,
    Button = _antd.Button,
    Spin = _antd.Spin;
var _ecCom = ecCom,
    WeaTop = _ecCom.WeaTop,
    WeaTab = _ecCom.WeaTab,
    WeaRightMenu = _ecCom.WeaRightMenu,
    WeaLeftRightLayout = _ecCom.WeaLeftRightLayout,
    WeaLeftTree = _ecCom.WeaLeftTree,
    WeaDialog = _ecCom.WeaDialog,
    WeaLocaleProvider = _ecCom.WeaLocaleProvider,
    WeaSearchGroup = _ecCom.WeaSearchGroup,
    WeaInput = _ecCom.WeaInput,
    WeaFormItem = _ecCom.WeaFormItem,
    WeaUpload = _ecCom.WeaUpload;

var _ecodeSDK$imp = ecodeSDK.imp(util),
    renderNoright = _ecodeSDK$imp.renderNoright,
    getSearchs = _ecodeSDK$imp.getSearchs,
    getCollectParams = _ecodeSDK$imp.getCollectParams;

var MainPage = (_dec = inject('mainStore'), _dec(_class = observer(_class = (_temp =
/*#__PURE__*/
function (_React$Component) {
  _inherits(MainPage, _React$Component);

  function MainPage() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, MainPage);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(MainPage)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _this.getSearchAdBtn = function () {
      var _this$props$mainStore = _this.props.mainStore,
          doSearch = _this$props$mainStore.doSearch,
          form = _this$props$mainStore.form,
          setShowSearchAd = _this$props$mainStore.setShowSearchAd;
      var btn = [React.createElement(Button, {
        type: "primary",
        onClick: doSearch
      }, WeaLocaleProvider.getLabel(197, '搜索')), React.createElement(Button, {
        type: "ghost",
        onClick: function onClick() {
          return form.resetForm();
        }
      }, WeaLocaleProvider.getLabel(2022, '重置')), React.createElement(Button, {
        type: "ghost",
        onClick: function onClick() {
          return setShowSearchAd(false);
        }
      }, WeaLocaleProvider.getLabel(201, '取消'))];
      return btn;
    };

    return _this;
  }

  _createClass(MainPage, [{
    key: "componentWillMount",
    //初始化
    value: function componentWillMount() {
      var mainStore = this.props.mainStore;
      mainStore.doInit();
    } // 高级搜索内部按钮

  }, {
    key: "render",
    value: function render() {
      var mainStore = this.props.mainStore;
      var title = mainStore.title,
          showSearchAd = mainStore.showSearchAd,
          condition = mainStore.condition,
          form = mainStore.form,
          tableStore = mainStore.tableStore,
          currentUrl = mainStore.currentUrl,
          loading = mainStore.loading,
          loadingInfo = mainStore.loadingInfo,
          selectedRowKeys = mainStore.selectedRowKeys,
          hasRight = mainStore.hasRight,
          hideLeft = mainStore.hideLeft;
      var getColumns = mainStore.getColumns,
          onOperatesClick = mainStore.onOperatesClick;
      var getTableDatas = mainStore.getTableDatas,
          _setShowSearchAd = mainStore.setShowSearchAd,
          doSearch = mainStore.doSearch,
          getRightMenu = mainStore.getRightMenu,
          getTopBtn = mainStore.getTopBtn;
      var rightLevel = mainStore.rightLevel;
      var rightMenu = getRightMenu();
      var collectParams = getCollectParams(currentUrl);
      var searchAdBtn = this.getSearchAdBtn();
      var topBtn = getTopBtn();
      return React.createElement("div", null, React.createElement(Spin, {
        size: "large",
        spinning: loading,
        tip: loadingInfo
      }, React.createElement(WeaRightMenu, {
        datas: rightMenu // 右键菜单
        ,
        collectParams: collectParams // 收藏功能: 配置之后显示 收藏、帮助、显示页面地址 这3个功能

      }, React.createElement(WeaTop, {
        title: title // 文字
        ,
        icon: React.createElement("img", {
          style: {
            width: 35,
            height: 35,
            marginTop: 8
          },
          src: "/westvalley/tool/am/image/ico_asset.png"
        }) // 左侧图标
        ,
        showDropIcon: true // 是否显示下拉按钮
        ,
        dropMenuDatas: rightMenu // 下拉菜单（和页面的右键菜单相同）
        ,
        dropMenuProps: {
          collectParams: collectParams
        } // 收藏功能: 配置之后显示 收藏、帮助、显示页面地址 这3个功能
        ,
        buttons: topBtn // 顶部按钮
        ,
        buttonSpace: 10 // 按钮之间的间隔
        ,
        loading: loading // 头部加载进度条

      }, React.createElement(WeaTab, {
        searchType: ['base', 'advanced'] // base：基础搜索框 advanced：显示高级搜索按钮
        ,
        showSearchAd: showSearchAd // 是否展开高级搜索面板
        ,
        setShowSearchAd: function setShowSearchAd(bool) {
          return _setShowSearchAd(bool);
        } //高级搜索面板受控
        ,
        searchsAd: getSearchs(form, toJS(condition), 2) // 高级搜索内部数据
        ,
        buttonsAd: searchAdBtn // 高级搜索内部按钮
        ,
        onSearch: getTableDatas // 点搜索按钮时的回调
        ,
        onSearchChange: function onSearchChange(v) {
          return form.updateFields({
            name: v
          });
        } // 在搜索框中输入的文字改变时的回调: 这里需要同步高级搜索和外部搜索框的值
        ,
        searchsBaseValue: form.getFormParams().name // 外部input搜索值受控: 这里和高级搜索的requestname同步

      }), React.createElement(WeaTable // table内部做了loading加载处理，页面就不需要再加了
      , {
        comsWeaTableStore: tableStore // table store
        ,
        hasOrder: true // 是否启用排序
        ,
        needScroll: true // 是否启用table内部列表滚动，将自适应到父级高度
        ,
        getColumns: getColumns // 重定列各列属性(一般带编辑功能，点击第一列字段的时候需要同样打开编辑弹框)
        ,
        onOperatesClick: onOperatesClick.bind(this) // 自定义操作按钮点击方法

      })))));
    }
  }]);

  return MainPage;
}(React.Component), _temp)) || _class) || _class);
ecodeSDK.exp(MainPage);

"use strict";

var _ecCom = ecCom,
    WeaTools = _ecCom.WeaTools; //获取主页面表单高级搜索字段信息

var getCondition = function getCondition(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/getListSearchCondition', 'GET', params);
}; //获取主页面分页控件数据


var getTableDatas = function getTableDatas(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/getListWeaTableDatas', 'GET', params);
}; //获取保存表单控件


var getSaveFormCondition = function getSaveFormCondition(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/getSaveFormCondition', 'GET', params);
}; //获取记录


var getRecordById = function getRecordById(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/getRecordById', 'GET', params);
}; //新增保存处理


var doAdd = function doAdd(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doSave', 'POST', params);
}; //编辑保存处理


var doEdit = function doEdit(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doSave', 'POST', params);
}; //删除


var doDelete = function doDelete(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doDelete', 'POST', params);
}; //禁用、启用


var doDisabledOrNot = function doDisabledOrNot(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doDisabledOrNot', 'POST', params);
}; //获取导入表单控件


var getImportFormCondition = function getImportFormCondition(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/getImportFormCondition', 'GET', params);
}; //导入


var doImport = function doImport(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doImport', 'POST', params);
}; //导出导入结果


var doExportImportResult = function doExportImportResult(params) {
  return WeaTools.callApi('/api/wwq/demo/hrm/doExportImportResult', 'POST', params);
};

var API = {
  getCondition: getCondition,
  getTableDatas: getTableDatas,
  getSaveFormCondition: getSaveFormCondition,
  getRecordById: getRecordById,
  doAdd: doAdd,
  doEdit: doEdit,
  doDelete: doDelete,
  doDisabledOrNot: doDisabledOrNot,
  doImport: doImport,
  getImportFormCondition: getImportFormCondition,
  doExportImportResult: doExportImportResult
};
ecodeSDK.exp(API);

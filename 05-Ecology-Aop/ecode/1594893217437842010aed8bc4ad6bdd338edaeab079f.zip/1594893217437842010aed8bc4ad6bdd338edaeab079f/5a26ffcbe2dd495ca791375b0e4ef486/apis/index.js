const { WeaTools } = ecCom;

//获取主页面表单高级搜索字段信息
const getCondition = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/getListSearchCondition', 'GET', params);
}

//获取主页面分页控件数据
const getTableDatas = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/getListWeaTableDatas', 'GET', params);
}

//获取保存表单控件
const getSaveFormCondition = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/getSaveFormCondition', 'GET', params);
}

//获取记录
const getRecordById = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/getRecordById', 'GET', params);
}

//新增保存处理
const doAdd = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doSave', 'POST', params);
}

//编辑保存处理
const doEdit = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doSave', 'POST', params);
}

//删除
const doDelete = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doDelete', 'POST', params);
}

//禁用、启用
const doDisabledOrNot = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doDisabledOrNot', 'POST', params);
}

//获取导入表单控件
const getImportFormCondition = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/getImportFormCondition', 'GET', params);
}

//导入
const doImport = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doImport', 'POST', params);
}

//导出导入结果
const doExportImportResult = params => {
  return WeaTools.callApi('/api/wwq/demo/hrm/doExportImportResult', 'POST', params);
}

const API = {
  getCondition
  , getTableDatas
  , getSaveFormCondition
  , getRecordById
  , doAdd
  , doEdit
  , doDelete
  , doDisabledOrNot
  , doImport
  , getImportFormCondition
  , doExportImportResult
};

ecodeSDK.exp(API);








